<?php
/**
 * Salient Child Theme functions and definitions
 */

function salient_child_enqueue_styles()
{
    wp_enqueue_style('salient-style', get_template_directory_uri() . '/style.css', array(), '1.0');
    wp_enqueue_style('salient-child-style', get_stylesheet_directory_uri() . '/style.css', array('salient-style'), '1.0');
}
add_action('wp_enqueue_scripts', 'salient_child_enqueue_styles');

/**
 * Enqueue Shape Seeds Scripts
 */
function shape_seeds_child_scripts()
{
    wp_enqueue_script('shape-seeds-script', get_stylesheet_directory_uri() . '/js/script.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'shape_seeds_child_scripts');

/**
 * Custom Post Type: Case Study (If not handled by Salient)
 */
function salient_child_register_case_study()
{
    $labels = array(
        'name' => _x('Case Studies', 'Post Type General Name', 'salient-child'),
        'singular_name' => _x('Case Study', 'Post Type Singular Name', 'salient-child'),
    );
    $args = array(
        'label' => __('Case Study', 'salient-child'),
        'labels' => $labels,
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-portfolio',
    );
    register_post_type('case_study', $args);
}
add_action('init', 'salient_child_register_case_study');

/**
 * Include Shape Seeds Shortcodes
 */
require get_stylesheet_directory() . '/shortcodes.php';
