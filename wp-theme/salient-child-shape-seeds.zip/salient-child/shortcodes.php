<?php
/**
 * Shape Seeds Shortcodes
 * Reusable design sections for the WordPress editor
 */

// ── Hero Shortcode ──────────────────────────────────────────
function ss_hero_shortcode($atts)
{
    $a = shortcode_atts(array(
        'image' => get_template_directory_uri() . '/images/astronaut.jpg',
        'eyebrow' => 'AI Experience Architect · Berlin',
        'title_1' => 'AI is the new baseline.',
        'title_2' => 'Welcome to the era',
        'title_3' => 'of Human Curation.',
        'desc' => 'Obsessed with market differentiation. Focused on LTV. I audit, map, and fix the <strong class="text-accent">AI Experience Debt</strong> quietly driving your users to competitors.',
        'cta_text' => 'Request a 15-Min Agent Teardown',
        'cta_url' => home_url('/contact'),
        'ghost_text' => 'Download Debt Checklist',
        'ghost_url' => '#checklist'
    ), $atts);

    ob_start(); ?>
    <section class="hero hero--cinematic">
        <img src="<?php echo esc_url($a['image']); ?>" alt="" class="hero-cinematic__bg" aria-hidden="true" />
        <div class="hero-cinematic__overlay"></div>
        <div class="container hero-cinematic__inner">
            <div class="hero-cinematic__content">
                <div class="hero__eyebrow hero-anim" data-delay="0">
                    <span class="hero-eyebrow__dot"></span>
                    <?php echo esc_html($a['eyebrow']); ?>
                </div>
                <h1 class="display-xl hero__title hero-anim" data-delay="1">
                    <span class="line">
                        <?php echo esc_html($a['title_1']); ?>
                    </span>
                    <span class="line text-accent">
                        <?php echo esc_html($a['title_2']); ?>
                    </span>
                    <span class="line">
                        <?php echo esc_html($a['title_3']); ?>
                    </span>
                </h1>
                <h2 class="hero__desc hero-anim" data-delay="2"
                    style="font-size: var(--text-lg); font-weight: 500; color: rgba(255, 255, 255, 0.8); line-height: 1.7;">
                    <?php echo wp_kses_post($a['desc']); ?>
                </h2>
                <div class="hero__actions hero-anim" data-delay="3">
                    <a href="<?php echo esc_url($a['cta_url']); ?>" class="btn btn--primary hero-cta">
                        <?php echo esc_html($a['cta_text']); ?>
                        <svg class="hero-cta__arrow" width="18" height="18" fill="none" stroke="currentColor"
                            stroke-width="2.5" viewBox="0 0 24 24">
                            <path d="M5 12h14M12 5l7 7-7 7" />
                        </svg>
                    </a>
                    <a href="<?php echo esc_url($a['ghost_url']); ?>" class="btn btn--ghost hero-cta--secondary">
                        <?php echo esc_html($a['ghost_text']); ?>
                    </a>
                </div>

                <div class="hero-cinematic__creds hero-anim" data-delay="4">
                    <div class="hero-cred">
                        <span class="hero-cred__n">15+</span>
                        <span class="hero-cred__l">Years<br>Experience</span>
                    </div>
                    <div class="hero-cred__sep"></div>
                    <div class="hero-cred">
                        <span class="hero-cred__n">3×</span>
                        <span class="hero-cred__l">Industries<br>Fintech · Web3 · SaaS</span>
                    </div>
                    <div class="hero-cred__sep"></div>
                    <div class="hero-cred">
                        <span class="hero-cred__n"><span class="hero-cred__dot"></span></span>
                        <span class="hero-cred__l">Available<br>for projects</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-cinematic__scroll">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path d="M12 5v14M5 12l7 7 7-7" />
            </svg>
        </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('ss_hero', 'ss_hero_shortcode');

// ── Problem Section Shortcode ──────────────────────────────
function ss_problem_shortcode($atts, $content = null)
{
    $a = shortcode_atts(array(
        'eyebrow' => 'The Problem',
        'title' => 'The "AI-First" Trap',
        'stat1_num' => '99%',
        'stat1_label' => 'Uptime your dashboards show',
        'stat2_num' => '↑ Churn',
        'stat2_label' => 'What your customers are actually experiencing',
        'stat3_num' => '"AI got confused"',
        'stat3_label' => 'Not an acceptable error message'
    ), $atts);

    ob_start(); ?>
    <section class="section" style="background:var(--color-surface);">
        <div class="container">
            <div class="problem-grid">
                <div class="reveal">
                    <p class="eyebrow">
                        <?php echo esc_html($a['eyebrow']); ?>
                    </p>
                    <h2 class="display-md" style="margin-top:12px;margin-bottom:24px;">
                        <?php echo esc_html($a['title']); ?>
                    </h2>
                    <?php echo wpautop(do_shortcode($content)); ?>
                </div>
                <div class="problem-stats reveal reveal-delay-1">
                    <div class="stat-card">
                        <div class="stat-card__number">
                            <?php echo esc_html($a['stat1_num']); ?>
                        </div>
                        <div class="stat-card__label">
                            <?php echo esc_html($a['stat1_label']); ?>
                        </div>
                    </div>
                    <div class="stat-card stat-card--accent">
                        <div class="stat-card__number">
                            <?php echo esc_html($a['stat2_num']); ?>
                        </div>
                        <div class="stat-card__label">
                            <?php echo esc_html($a['stat2_label']); ?>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-card__number">
                            <?php echo esc_html($a['stat3_num']); ?>
                        </div>
                        <div class="stat-card__label">
                            <?php echo esc_html($a['stat3_label']); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('ss_problem', 'ss_problem_shortcode');

// ── CTA Shortcode ───────────────────────────────────────────
function ss_cta_shortcode($atts)
{
    $a = shortcode_atts(array(
        'eyebrow' => 'Project Partnership',
        'title' => 'Ready to build a Moat?',
        'url' => home_url('/contact'),
        'button_text' => 'Schedule a Strategy Session'
    ), $atts);

    ob_start(); ?>
    <section class="section section--cta">
        <div class="container">
            <div class="cta-box reveal">
                <p class="eyebrow"
                    style="font-size:0.8rem;font-weight:700;text-transform:uppercase;letter-spacing:0.12em;margin-bottom:16px;">
                    <?php echo esc_html($a['eyebrow']); ?>
                </p>
                <h2 class="display-md" style="margin-bottom:16px;color:#fff;">
                    <?php echo esc_html($a['title']); ?>
                </h2>
                <div class="cta-content">
                    <?php // Content can be handled via inner content if needed, for now standardizing ?>
                    <p
                        style="max-width:640px;margin:0 auto 40px;color:rgba(255,255,255,0.85);font-size:1.1rem; line-height: 1.6;">
                        "Good enough" is a high-risk strategy in an AI-commoditized world. Let's discuss how to turn your
                        product into a premium market leader.
                    </p>
                </div>
                <a href="<?php echo esc_url($a['url']); ?>" class="btn btn--primary cta-box__btn">
                    <?php echo esc_html($a['button_text']); ?>
                    <svg width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
                        <path d="M5 12h14M12 5l7 7-7 7" />
                    </svg>
                </a>
            </div>
        </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('ss_cta', 'ss_cta_shortcode');

// ── Services Shortcode ──────────────────────────────────────
function ss_services_shortcode($atts)
{
    ob_start(); ?>
    <section class="section" style="background:var(--color-surface);">
        <div class="container">
            <div class="section-header section-header--center reveal">
                <p class="eyebrow">Core Services</p>
                <h2 class="display-md">What I Fix</h2>
                <p>Three focused engagements to stop AI Experience Debt before it kills your retention.</p>
            </div>
            <div class="services-list">
                <div class="service-card reveal">
                    <div class="service-card__number">01</div>
                    <div class="service-card__content">
                        <h3 class="service-card__title">The Agentic Logic Audit</h3>
                        <p class="service-card__desc">AI fails in ways that are hard to communicate. I don't look at your
                            code — I map your <strong>Decision Trees</strong>.</p>
                    </div>
                </div>
                <div class="service-card reveal reveal-delay-1">
                    <div class="service-card__number">02</div>
                    <div class="service-card__content">
                        <h3 class="service-card__title">Human-in-the-Loop Design</h3>
                        <p class="service-card__desc">I design intuitive "Command Center" dashboards that allow your team to
                            monitor and override AI agents.</p>
                    </div>
                </div>
                <div class="service-card reveal reveal-delay-2">
                    <div class="service-card__number">03</div>
                    <div class="service-card__content">
                        <h3 class="service-card__title">Recovery UX & Failsafes</h3>
                        <p class="service-card__desc">I design the fallback flows and human handoff experience that saves
                            the customer relationship.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('ss_services', 'ss_services_shortcode');

// ── ROI Shortcode ───────────────────────────────────────────
function ss_roi_shortcode($atts)
{
    ob_start(); ?>
    <section id="roi" class="section" style="background:var(--color-surface);">
        <div class="container">
            <div class="section-header section-header--center reveal">
                <p class="eyebrow">For CEOs / PMs</p>
                <h2 class="display-md">Design is a Defensive Strategy.</h2>
            </div>
            <div class="services-list" style="margin-top: 56px;">
                <div class="service-card reveal">
                    <div class="service-card__content">
                        <h3 class="service-card__title" style="font-size: 1.25rem;">Retention over Acquisition</h3>
                        <p class="service-card__desc">It is 5x cheaper to keep a user who loves your UI than to acquire a
                            new one.</p>
                    </div>
                </div>
                <div class="service-card reveal reveal-delay-1">
                    <div class="service-card__content">
                        <h3 class="service-card__title" style="font-size: 1.25rem;">Commanding Premium Pricing</h3>
                        <p class="service-card__desc">Users pay for "experience." High-end design justifies higher margins.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('ss_roi', 'ss_roi_shortcode');

// ── Banner Shortcode (Speedbump) ───────────────────────────
function ss_banner_shortcode($atts, $content = null)
{
    $a = shortcode_atts(array(
        'accent_text' => ''
    ), $atts);

    ob_start(); ?>
    <section class="banner-speedbump">
        <div class="container reveal">
            <h2 class="display-md" style="max-width: 800px; margin: 0 auto; line-height: 1.2;">
                <?php echo wp_kses_post($content); ?>
                <?php if ($a['accent_text']): ?>
                    <br><span class="text-accent">
                        <?php echo esc_html($a['accent_text']); ?>
                    </span>
                <?php endif; ?>
            </h2>
        </div>
    </section>
    <?php return ob_get_clean();
}
add_shortcode('ss_banner', 'ss_banner_shortcode');
