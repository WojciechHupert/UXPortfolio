<?php
/**
 * The header for our Shape Seeds child theme
 *
 * This completely bypasses Salient's default header to ensure 100% design fidelity.
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php
    if (function_exists('wp_body_open')) {
        wp_body_open();
    }
    ?>

    <!-- ── Navigation ──────────────────────────────────────── -->
    <nav class="nav">
        <div class="nav__inner">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="nav__logo">Shape<span>.</span>Seeds</a>
            <ul class="nav__links">
                <li><a href="<?php echo esc_url(home_url('/#approach')); ?>">Approach</a></li>
                <li><a href="<?php echo esc_url(home_url('/#work')); ?>">Work</a></li>
                <li><a href="<?php echo esc_url(home_url('/#services')); ?>">Services</a></li>
                <li><a href="<?php echo esc_url(home_url('/about')); ?>">About</a></li>
                <li><a href="<?php echo esc_url(home_url('/contact')); ?>" class="nav__cta">Contact</a></li>
            </ul>
            <button class="nav__burger" id="navBurger" aria-label="Open menu" aria-expanded="false">
                <span></span><span></span><span></span>
            </button>
        </div>
        <div class="nav__mobile" id="navMobile">
            <a href="<?php echo esc_url(home_url('/#approach')); ?>">Approach</a>
            <a href="<?php echo esc_url(home_url('/#work')); ?>">Work</a>
            <a href="<?php echo esc_url(home_url('/#services')); ?>">Services</a>
            <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
            <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
        </div>
    </nav>

    <main class="page-wrapper">