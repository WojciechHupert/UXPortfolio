<?php
/**
 * The footer for our Shape Seeds child theme
 *
 * This completely bypasses Salient's default footer to ensure 100% design fidelity.
 */
?>
</main> <!-- /.page-wrapper -->

<!-- ── Footer ──────────────────────────────────────────── -->
<footer class="footer">
    <div class="container">
        <div class="footer__inner">
            <span class="footer__logo">Shape<span>.</span>Seeds</span>
            <nav class="footer__links">
                <a href="<?php echo esc_url(home_url('/#approach')); ?>">Approach</a>
                <a href="<?php echo esc_url(home_url('/#work')); ?>">Work</a>
                <a href="<?php echo esc_url(home_url('/#services')); ?>">Services</a>
                <a href="<?php echo esc_url(home_url('/about')); ?>">About</a>
                <a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a>
            </nav>
            <p class="footer__copy">©
                <?php echo date('Y'); ?> Shape Seeds. All rights reserved.
            </p>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
</body>

</html>